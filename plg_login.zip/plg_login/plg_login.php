<?php

class plgUserExample extends JPlugin
{
	
	public function onUserAfterLogin( $options)
	{
        $config = JFactory::getConfig();
        echo 'Welcome you are login to  ' . $config->get( 'sitename' );
		
		
	}

}
?>